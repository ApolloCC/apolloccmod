# SpartanWeaponry-API
API for the mod Spartan Weaponry (beta-1.2.0 or above)
