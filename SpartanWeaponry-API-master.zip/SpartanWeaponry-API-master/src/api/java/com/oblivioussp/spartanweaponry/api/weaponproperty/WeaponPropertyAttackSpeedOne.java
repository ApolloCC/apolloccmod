package com.oblivioussp.spartanweaponry.api.weaponproperty;

import java.util.List;

import com.oblivioussp.spartanweaponry.api.SpartanWeaponryAPI;
import com.oblivioussp.spartanweaponry.api.ToolMaterialEx;
import com.oblivioussp.spartanweaponry.api.WeaponProperties;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;

public class WeaponPropertyAttackSpeedOne extends WeaponPropertyWithCallback
{
	public WeaponPropertyAttackSpeedOne(String propType, String propModId, float propMagnitude)
	{
		super(propType, propModId, propMagnitude);
	}

	@Override
	protected void addTooltipDescription(ItemStack stack, List<String> tooltip) 
	{
		tooltip.add(TextFormatting.ITALIC + "  " + SpartanWeaponryAPI.internalHandler.translateFormattedString(type + ".desc", "tooltip", modId, MathHelper.floor((magnitude - 1.0f) * 100.0f)));
	}

	@Override
	public float modifyAttackSpeed(ToolMaterialEx material, float baseAttackSpeed, float initialAttackSpeed, EntityLivingBase attacker, EntityLivingBase victim) 
	{
		if(attacker == null || victim == null)
			return baseAttackSpeed;
		float bonusDamage = ((this.getMagnitude() - 1.0f) * baseAttackSpeed);
		
		switch(type)
		{
			default:
				return baseAttackSpeed;
		}
	}
}
