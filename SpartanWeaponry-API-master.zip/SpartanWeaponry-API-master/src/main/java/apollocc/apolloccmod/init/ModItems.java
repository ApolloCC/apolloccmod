package apollocc.apolloccmod.init;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;
import apollocc.apolloccmod.ApolloCCMod;

@ObjectHolder(ApolloCCMod.MODID)
public class ModItems {
	
	public static final Item DEMONIC_OBSIDIAN_INGOT= null;
	
}
