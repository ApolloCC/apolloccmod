package apollocc.apolloccmod;


import apollocc.apolloccmod.init.ModBlocks;
import apollocc.apolloccmod.util.RegistryUtil;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@EventBusSubscriber(modid = ApolloCCMod.MODID)
public class RegistrationHandler {

	@SubscribeEvent
	public static void registerItems(Register<Item> event) {
		final Item[] items = {
				RegistryUtil.setItemName(new Item(), "demonic_obsidian_ingot").setCreativeTab(CreativeTabs.MISC),
		};
		final Item[]itemBlocks = {
				new ItemBlock(ModBlocks.DEMONIC_OBSIDIAN_ORE).setRegistryName(ModBlocks.DEMONIC_OBSIDIAN_ORE.getRegistryName())
		};

		event.getRegistry().registerAll(items);
		event.getRegistry().registerAll(itemBlocks);

	}

	@SubscribeEvent
	public static void registerBlocks(Register<Block> event) {
		final Block[] Blocks = {
			RegistryUtil.setBlockName(new Block(Material.ROCK), "demonic_obsidian_ore").setCreativeTab(CreativeTabs.BUILDING_BLOCKS)
		};
		
		event.getRegistry().registerAll(Blocks);
		
	}
	

}

