package apollocc.apolloccmod.util;

import apollocc.apolloccmod.ApolloCCMod;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.BlockVine;
import net.minecraft.item.Item;
import apollocc.apolloccmod.item.MajestySword;

public class RegistryUtilVine {
	public static Block setBlockVineName(final BlockVine block, final String name) {
		block.setRegistryName(ApolloCCMod.MODID, name).setTranslationKey(ApolloCCMod.ModID + "." + name);
		return block;
	}



}
	

