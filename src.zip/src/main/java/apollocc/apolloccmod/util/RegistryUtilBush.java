package apollocc.apolloccmod.util;

import apollocc.apolloccmod.ApolloCCMod;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.item.Item;
import apollocc.apolloccmod.item.MajestySword;

public class RegistryUtilBush {
	public static Block setBlockBushName(final BlockBush block, final String name) {
		block.setRegistryName(ApolloCCMod.MODID, name).setTranslationKey(ApolloCCMod.ModID + "." + name);
		return block;
	}



}
	

