package apollocc.apolloccmod.util;

import apollocc.apolloccmod.ApolloCCMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class Reference {

	public static String ModID = ApolloCCMod.MODID;
	};

