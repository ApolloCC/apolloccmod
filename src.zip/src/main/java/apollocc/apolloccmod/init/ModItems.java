package apollocc.apolloccmod.init;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;
import apollocc.apolloccmod.ApolloCCMod;

@ObjectHolder(ApolloCCMod.MODID)
public class ModItems {
	
	public static final Item LUMINITE_INGOT= null;
	
	public static final Item LUMINITE_HELMET = null;
	public static final Item LUMINITE_CHESTPLATE = null;
	public static final Item LUMINITE_LEGGINGS = null;
	public static final Item LUMINITE_BOOTS = null;
	public static final Item CORAL_SILK_HELMET = null;
	public static final Item CORAL_SILK_CHESTPLATE = null;
	public static final Item CORAL_SILK_LEGGINGS = null;
	public static final Item CORAL_SILK_BOOTS = null;
	
}
