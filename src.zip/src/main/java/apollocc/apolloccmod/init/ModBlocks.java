package apollocc.apolloccmod.init;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.BlockGrass;
import net.minecraft.block.BlockVine;
import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;
import apollocc.apolloccmod.ApolloCCMod;
import apollocc.apolloccmod.block.CustomBlockBush;
import apollocc.apolloccmod.block.GlowingVine;
import net.minecraft.init.Blocks;

@SuppressWarnings("unused")
@ObjectHolder (ApolloCCMod.MODID)
public class ModBlocks {
	
	public static final Block LUMINITE_ORE = null;
	public static final Block MOON_STONE = null;
	public static final CustomBlockBush LUNAR_ROSE = null;
	public static final Block PRISMITE_ORE = null;
	public static final BlockVine GLOWING_VINE = null;

		
}
