package apollocc.apolloccmod.init;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;
import apollocc.apolloccmod.ApolloCCMod;
import apollocc.apolloccmod.block.CustomBlockBush;

@ObjectHolder (ApolloCCMod.MODID)
public class ModBlocks {
	
	public static final Block LUMINITE_ORE = null;
	public static final Block MOON_STONE = null;
	public static final CustomBlockBush LUNAR_ROSE = null;
		
}
