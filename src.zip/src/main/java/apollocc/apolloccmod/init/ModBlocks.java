package apollocc.apolloccmod.init;

import net.minecraft.block.Block;
import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;
import apollocc.apolloccmod.ApolloCCMod;

@ObjectHolder (ApolloCCMod.MODID)
public class ModBlocks {
	
	public static final Block DEMONIC_OBSIDIAN_ORE = null;

}
