package apollocc.apolloccmod.init;

import apollocc.apolloccmod.potion.CustomPotion;
import apollocc.apolloccmod.world.WorldEvents;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.PotionTypes;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionHelper;
import net.minecraft.potion.PotionType;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

public class PotionInit 
{
	
	public static final Potion GREATER_HEALING = new CustomPotion("greater_healing_potion", false, 12775401, 0, 0).registerPotionAttributeModifier(SharedMonsterAttributes.MAX_HEALTH, MathHelper.getRandomUUID().toString(), 1.0D, 1).setPotionName("effect.superheal");
	
	public static final PotionType GREATER_HEALING_POTION = new PotionType("greater_healing_potion", new PotionEffect[] {new PotionEffect(GREATER_HEALING, 2400)}).setRegistryName("greater_healing_potion");
	public static final PotionType LONG_GREATER_HEALING_POTION = new PotionType("greater_healing_potion", new PotionEffect[] {new PotionEffect(GREATER_HEALING, 4800)}).setRegistryName("long_greater_healing_potion");
	
	public static void registerPotions()
	{
		registerPotion(GREATER_HEALING_POTION, LONG_GREATER_HEALING_POTION, GREATER_HEALING);
		
		registerPotionMixes();
	}
	
	private static void registerPotion(PotionType defaultPotion, PotionType longPotion, Potion effect)
	{
		ForgeRegistries.POTIONS.register(effect);
		ForgeRegistries.POTION_TYPES.register(defaultPotion);
		ForgeRegistries.POTION_TYPES.register(longPotion);
	}
	private static void registerPotionMixes()
	{
		PotionHelper.addMix(PotionTypes.HEALING, Items.EMERALD, GREATER_HEALING_POTION);
	}
}
