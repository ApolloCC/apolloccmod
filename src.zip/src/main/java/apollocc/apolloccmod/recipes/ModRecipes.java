package apollocc.apolloccmod.recipes;

import apollocc.apolloccmod.init.ModBlocks;
import apollocc.apolloccmod.init.ModItems;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModRecipes {

	public static void initSmelting() {
		GameRegistry.addSmelting(ModBlocks.LUMINITE_ORE, new ItemStack(ModItems.LUMINITE_INGOT), 10.0F);
	}
	
}
