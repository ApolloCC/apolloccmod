package apollocc.apolloccmod.materials;

import apollocc.apolloccmod.ApolloCCMod;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraftforge.common.util.EnumHelper;

public class ArmorMaterials {
	
	public static final ArmorMaterial CORAL_SILK_ARMOR = EnumHelper.addArmorMaterial(ApolloCCMod.MODID + ":" + "coral_silk_armor", ApolloCCMod.MODID + ":coral_silk", 3000, new int[]{3, 6, 5, 5}, 6, SoundEvents.ITEM_ARMOR_EQUIP_LEATHER, 0);
	public static final ArmorMaterial LUMINITE_ARMOR = EnumHelper.addArmorMaterial(ApolloCCMod.MODID + ":" + "luminite_armor", ApolloCCMod.MODID + ":luminite", 3000, new int[]{4, 10, 12, 6}, 5, SoundEvents.ITEM_ARMOR_EQUIP_GENERIC, 6);
	
}
