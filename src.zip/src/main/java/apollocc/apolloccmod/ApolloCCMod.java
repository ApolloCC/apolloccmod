package apollocc.apolloccmod;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import apollocc.apolloccmod.init.PotionInit;
import apollocc.apolloccmod.recipes.ModRecipes;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid = ApolloCCMod.MODID, name = ApolloCCMod.NAME, version = ApolloCCMod.VERSION, acceptedMinecraftVersions = ApolloCCMod.MC_VERSION)

public class ApolloCCMod {
	private String modid = ApolloCCMod.MODID;
	public static final String ModID = ApolloCCMod.MODID;
	public static final String MODID = "apolloccmod";
	public static final String NAME = "ApolloCC Mod";
	public static final String VERSION = "0.1.0";
	public static final String MC_VERSION = "[1.12.2]";

	public static final Logger LOGGER = LogManager.getLogger(ApolloCCMod.MODID);
	

	@EventHandler
	public void preInit(FMLPreInitializationEvent event) {
	}
	@EventHandler
	public void preInit(FMLInitializationEvent event) {
		ModRecipes.initSmelting();
	}

	@EventHandler
	public void postInit(FMLPostInitializationEvent event) {
        
	}

}