package apollocc.apolloccmod.proxy;

import apollocc.apolloccmod.init.ModItems;
import net.minecraft.world.biome.BiomeHell;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class CommonProxy{
	public void onPlayerTick(World world, EntityPlayer player, ItemStack armor, Items item) {
	if (player.getItemStackFromSlot(EntityEquipmentSlot.FEET).getItem().equals(Items.AIR)) {
		player.stepHeight = 0.0F;
		player.fallDistance = 4F;
	}
	}
}
