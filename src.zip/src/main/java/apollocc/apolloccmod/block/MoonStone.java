package apollocc.apolloccmod.block;

import apollocc.apolloccmod.init.ModBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.BlockRenderLayer;


public class MoonStone extends Block{
	public MoonStone() {
		super(Material.ROCK);
		setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
		setTranslationKey("moon_stone");
		setHardness(2.0F);
		setResistance(2.0F);
		setHarvestLevel("pickaxe", 3);

	}
}

