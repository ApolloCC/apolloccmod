package apollocc.apolloccmod.block;

import net.minecraft.block.BlockBush;
import net.minecraft.block.material.Material;

public class CustomBlockBush extends BlockBush{
	public CustomBlockBush(Material material) {
		super(material);
	}

}
