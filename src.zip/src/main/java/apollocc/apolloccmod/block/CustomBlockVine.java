package apollocc.apolloccmod.block;

import net.minecraft.block.BlockVine;
import net.minecraft.block.material.Material;

public class CustomBlockVine extends BlockVine {
	public CustomBlockVine(Material material) {
		super ();
	}
}
