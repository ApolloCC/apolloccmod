package apollocc.apolloccmod.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;

public class LunarRose extends CustomBlockBush{
	public LunarRose() {
		super(Material.PLANTS);
		setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
		setTranslationKey("lunar_rose");
	}

}
