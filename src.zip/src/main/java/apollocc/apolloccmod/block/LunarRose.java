package apollocc.apolloccmod.block;

import apollocc.apolloccmod.init.ModBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenFlowers;

public class LunarRose extends CustomBlockBush{
	public LunarRose(Material material) {
		super(Material.GRASS);
		setCreativeTab(CreativeTabs.BUILDING_BLOCKS).setLightLevel(3);
		setTranslationKey("lunar_rose");
		setSoundType(SoundType.PLANT);
		
	}
	  @Override
	   public boolean canPlaceBlockAt(World worldIn, BlockPos pos) {
	      // Check the block that new custom block will be placed on, so y: -1 here
	      return canPlaceBlockOn(worldIn.getBlockState(pos.add(0, -1, 0)).getBlock());
}
	  protected boolean canPlaceBlockOn(Block block) {
		   return block == Blocks.GRASS || block == ModBlocks.MOON_STONE;
	  }
}