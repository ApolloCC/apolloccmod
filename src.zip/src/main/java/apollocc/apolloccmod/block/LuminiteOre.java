package apollocc.apolloccmod.block;

import apollocc.apolloccmod.init.ModBlocks;
import net.minecraft.block.BlockMushroom;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.BlockRenderLayer;


public class LuminiteOre extends Block{
	public LuminiteOre() {
		super(Material.ROCK);
		setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
		setTranslationKey("luminite_ore");
		setHardness(10.0F);
		setResistance(5.0F);
		setHarvestLevel("pickaxe", 3);

	}
}

