package apollocc.apolloccmod.block;

import java.util.Random;

import apollocc.apolloccmod.init.ModBlocks;
import apollocc.apolloccmod.init.ModItems;
import net.minecraft.block.BlockMushroom;
import net.minecraft.block.Block;
import net.minecraft.block.BlockOre;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.util.BlockRenderLayer;


public class PrismiteOre extends BlockOre{
	public PrismiteOre() {
		
		setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
		setTranslationKey("prismite_ore");
		setHardness(10.0F);
		setResistance(5.0F);
		setHarvestLevel("pickaxe", 3);

}
}
