package apollocc.apolloccmod.client;

import apollocc.apolloccmod.ApolloCCMod;
import apollocc.apolloccmod.init.ModBlocks;
import apollocc.apolloccmod.init.ModItems;
import apollocc.apolloccmod.item.CelestialSword;
import apollocc.apolloccmod.item.Kusanagi;
import apollocc.apolloccmod.item.MajestySword;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@EventBusSubscriber(value = Side.CLIENT, modid = ApolloCCMod.MODID)
public class ModelRegistrationHandler {

	@SubscribeEvent
	public static void registerModels(ModelRegistryEvent event) {
		registerModel(ModItems.LUMINITE_INGOT, 0);
		registerModel(ModItems.PRISMITE_CRYSTAL, 0);
		registerModel(ModItems.LEAF_BOW, 0);
		
		registerModel(MajestySword.majestySword, 0);
		registerModel(Kusanagi.Kusanagi, 0);
		registerModel(CelestialSword.celestialSword, 0);
		
		registerModel(ModItems.LUMINITE_HELMET, 0);
		registerModel(ModItems.LUMINITE_CHESTPLATE, 0);
		registerModel(ModItems.LUMINITE_LEGGINGS, 0);
		registerModel(ModItems.LUMINITE_BOOTS, 0);
		registerModel(ModItems.CORAL_SILK_HELMET, 0);
		registerModel(ModItems.CORAL_SILK_CHESTPLATE, 0);
		registerModel(ModItems.CORAL_SILK_LEGGINGS, 0);
		registerModel(ModItems.CORAL_SILK_BOOTS, 0);
		
		registerModel(Item.getItemFromBlock(ModBlocks.PRISMITE_ORE), 0);
		registerModel(Item.getItemFromBlock(ModBlocks.LUMINITE_ORE), 0);
		registerModel(Item.getItemFromBlock(ModBlocks.MOON_STONE), 0);
		registerModel(Item.getItemFromBlock(ModBlocks.LUNAR_ROSE), 0);
		registerModel(Item.getItemFromBlock(ModBlocks.GLOWING_VINE), 0);
	}

	private static void registerModel(Item item, int meta) {
		ModelLoader.setCustomModelResourceLocation(item, meta, new ModelResourceLocation(item.getRegistryName(), "inventory"));
	}

}
