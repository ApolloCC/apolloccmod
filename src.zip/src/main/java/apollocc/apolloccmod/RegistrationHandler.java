package apollocc.apolloccmod;


import apollocc.apolloccmod.block.CustomBlockBush;
import apollocc.apolloccmod.block.GlowingVine;
import apollocc.apolloccmod.block.LuminiteOre;
import apollocc.apolloccmod.init.ModBlocks;
import apollocc.apolloccmod.init.ModItems;
import apollocc.apolloccmod.init.PotionInit;
import apollocc.apolloccmod.item.ItemCoralSilkArmor;
import apollocc.apolloccmod.item.ItemLuminiteArmor;
import apollocc.apolloccmod.item.LeafBow;
import apollocc.apolloccmod.util.RegistryUtil;
import apollocc.apolloccmod.util.RegistryUtilBush;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.BlockVine;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockStateBase;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBlockSpecial;
import net.minecraft.item.ItemBow;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import apollocc.apolloccmod.materials.ArmorMaterials;
import apollocc.apolloccmod.util.RegistryUtil;
import apollocc.apolloccmod.block.LunarRose;


@EventBusSubscriber(modid = ApolloCCMod.MODID)
public class RegistrationHandler {

	@SubscribeEvent
	public static void registerItems(Register<Item> event) {
		final Item[] items = {
				RegistryUtil.setItemName(new Item(), "prismite_crystal").setCreativeTab(CreativeTabs.MISC),
				RegistryUtil.setItemName(new Item(), "luminite_ingot").setCreativeTab(CreativeTabs.MISC),
				RegistryUtil.setItemName(new ItemLuminiteArmor(ArmorMaterials.LUMINITE_ARMOR, EntityEquipmentSlot.HEAD), "luminite_helmet").setCreativeTab(CreativeTabs.MISC),
				RegistryUtil.setItemName(new ItemLuminiteArmor(ArmorMaterials.LUMINITE_ARMOR, EntityEquipmentSlot.CHEST), "luminite_chestplate").setCreativeTab(CreativeTabs.MISC),
				RegistryUtil.setItemName(new ItemLuminiteArmor(ArmorMaterials.LUMINITE_ARMOR, EntityEquipmentSlot.LEGS), "luminite_leggings").setCreativeTab(CreativeTabs.MISC),
				RegistryUtil.setItemName(new ItemLuminiteArmor(ArmorMaterials.LUMINITE_ARMOR, EntityEquipmentSlot.FEET), "luminite_boots").setCreativeTab(CreativeTabs.MISC),
				RegistryUtil.setItemName(new ItemCoralSilkArmor(ArmorMaterials.CORAL_SILK_ARMOR, EntityEquipmentSlot.HEAD), "coral_silk_helmet").setCreativeTab(CreativeTabs.MISC),
				RegistryUtil.setItemName(new ItemCoralSilkArmor(ArmorMaterials.CORAL_SILK_ARMOR, EntityEquipmentSlot.CHEST), "coral_silk_chestplate").setCreativeTab(CreativeTabs.MISC),
				RegistryUtil.setItemName(new ItemCoralSilkArmor(ArmorMaterials.CORAL_SILK_ARMOR, EntityEquipmentSlot.LEGS), "coral_silk_leggings").setCreativeTab(CreativeTabs.MISC),
				RegistryUtil.setItemName(new ItemCoralSilkArmor(ArmorMaterials.CORAL_SILK_ARMOR, EntityEquipmentSlot.FEET), "coral_silk_boots").setCreativeTab(CreativeTabs.MISC),
				RegistryUtil.setItemName(new LeafBow(), "leaf_bow").setCreativeTab(CreativeTabs.COMBAT),
		};
		final Item[]itemBlocks = {
				new ItemBlock(ModBlocks.LUMINITE_ORE).setRegistryName(ModBlocks.LUMINITE_ORE.getRegistryName()),
				new ItemBlock(ModBlocks.MOON_STONE).setRegistryName(ModBlocks.MOON_STONE.getRegistryName()),
				new ItemBlock(ModBlocks.LUNAR_ROSE).setRegistryName(ModBlocks.LUNAR_ROSE.getRegistryName()),
				new ItemBlock(ModBlocks.PRISMITE_ORE).setRegistryName(ModBlocks.PRISMITE_ORE.getRegistryName()),
				new ItemBlock(ModBlocks.GLOWING_VINE).setRegistryName(ModBlocks.GLOWING_VINE.getRegistryName())
	
		};

		event.getRegistry().registerAll(items);
		event.getRegistry().registerAll(itemBlocks);

	}

	@SubscribeEvent
	public static void registerBlocks(Register<Block> event) {
		final Block[] Blocks = {
			RegistryUtil.setBlockName(new Block(Material.ROCK), "luminite_ore").setCreativeTab(CreativeTabs.BUILDING_BLOCKS).setHardness(10.0F),
			RegistryUtil.setBlockName(new Block(Material.ROCK), "moon_stone").setCreativeTab(CreativeTabs.BUILDING_BLOCKS).setHardness(2.0F),
			RegistryUtil.setBlockName(new Block(Material.ROCK), "prismite_ore").setCreativeTab(CreativeTabs.BUILDING_BLOCKS).setHardness(10.0F),
	
		};
		
		event.getRegistry().registerAll(Blocks);
		}
	@SubscribeEvent
	public static void registerBlockVines(Register<Block> event) {
		final BlockVine[] Blocks = {
				RegistryUtil.setBlockVineName(new GlowingVine(Material.VINE), "glowing_vine")
		};
		
		event.getRegistry().registerAll(Blocks);
	}
	@SubscribeEvent
	public static void registerBlockBush(Register<Block> event) {
		final CustomBlockBush[] Blocks = {
			RegistryUtil.setBlockBushName(new LunarRose(Material.GRASS), "lunar_rose")
				
		};
		
		event.getRegistry().registerAll(Blocks);
		}
}



