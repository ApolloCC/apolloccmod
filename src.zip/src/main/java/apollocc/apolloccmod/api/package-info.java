/**
 * 
 */
/**
 * API for Spartan Weaponry
 * @author ObliviousSpartan
 *
 */
@API(owner = "spartanweaponry", apiVersion = "5", provides = "spartanweaponry_api")
package apollocc.apolloccmod.api;

import net.minecraftforge.fml.common.API;
