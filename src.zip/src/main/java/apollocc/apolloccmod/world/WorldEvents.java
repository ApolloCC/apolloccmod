package apollocc.apolloccmod.world;

import java.util.UUID;

import apollocc.apolloccmod.init.PotionInit;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.PlayerTickEvent;
import net.minecraft.world.gen.ChunkGeneratorOverworld;

@EventBusSubscriber
public class WorldEvents 
{	
	
	@SubscribeEvent
	public void performEffect(EntityLivingBase entityLivingBaseIn, int amplifier, PlayerTickEvent event) {
	boolean isActive = false;
	if(event.player.isPotionActive(PotionInit.GREATER_HEALING))isActive = true;
	
	if(isActive) 
	{
		entityLivingBaseIn.heal((float)Math.max(6 << amplifier, 0));
	}
	}
	
	@SubscribeEvent
	public static void GreaterHealing(PlayerTickEvent event) { 
	boolean isActive = false;
	if(event.player.isPotionActive(PotionInit.GREATER_HEALING))isActive = true;
	
	if(isActive) 
	{
	}
	
	
}
}