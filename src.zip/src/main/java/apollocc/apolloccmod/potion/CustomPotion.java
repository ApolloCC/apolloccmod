package apollocc.apolloccmod.potion;

import java.util.UUID;

import apollocc.apolloccmod.util.Reference;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.Potion;
import net.minecraft.util.ResourceLocation;

public class CustomPotion extends Potion
{
	public CustomPotion(String name, boolean isBadPotion, int colour, int iconIndexX, int iconIndexY)
	{
			super(isBadPotion, colour);
			setPotionName("Greater_Healing_Potion");
			setIconIndex(iconIndexX, iconIndexY);
			setRegistryName(new ResourceLocation(Reference.ModID + ":" + name));
	}
	
	@Override
	public boolean hasStatusIcon()
	{
		Minecraft.getMinecraft().getTextureManager().bindTexture(new ResourceLocation(Reference.ModID + "textures/gui/potion_effects.png"));
		return true;
	}	
	public Potion registerPotionAttributeModifier(IAttribute attribute, String uniqueId, double ammount, int operation)
	{
	    AttributeModifier attributemodifier = new AttributeModifier(UUID.fromString(uniqueId), this.getName(), ammount, operation);
	    this.getAttributeModifierMap().put(attribute, attributemodifier);
	    return this;
	}
}
		


