package apollocc.apolloccmod.item;

import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class PrismiteCrystal {

}
