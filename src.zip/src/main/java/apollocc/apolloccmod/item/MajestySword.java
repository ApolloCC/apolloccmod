package apollocc.apolloccmod.item;

import com.oblivioussp.spartanweaponry.api.DamageHelper;
import com.oblivioussp.spartanweaponry.api.DamageHelper.WeaponType;
import com.oblivioussp.spartanweaponry.api.SpartanWeaponryAPI;
import com.oblivioussp.spartanweaponry.api.ToolMaterialEx;
import com.oblivioussp.spartanweaponry.api.WeaponProperties;
import com.oblivioussp.spartanweaponry.api.weaponproperty.WeaponProperty;
import com.oblivioussp.spartanweaponry.api.weaponproperty.WeaponPropertyDamageAbsorb;

import apollocc.apolloccmod.ApolloCCMod;
import apollocc.apolloccmod.RegistrationHandler;
import apollocc.apolloccmod.util.Reference;
import apollocc.apolloccmod.util.RegistryUtil;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.registries.IForgeRegistry;
@EventBusSubscriber
public class MajestySword
{
    public static ToolMaterialEx materialDemonicObsidian = new ToolMaterialEx("demonicobsidian", "ingotDemonicObsidian", Reference.ModID, 0x0F6363, 0x107272, 4, 2048, 14.5f, 8.0f, 18);

    public static Item majestySword = null;
    
    public static Item setItemName(final Item item, final String name) {
    	item.setRegistryName(ApolloCCMod.MODID, name).setTranslationKey(ApolloCCMod.MODID + "." + name);
    	return item;
    }
	
    @SubscribeEvent
    public static void onItemRegisterEvent(RegistryEvent.Register<Item> ev)
    {
        IForgeRegistry<Item> reg = ev.getRegistry();

        majestySword = SpartanWeaponryAPI.createLongsword(materialDemonicObsidian, Reference.ModID, DamageHelper.getDamage(WeaponType.LONGSWORD, materialDemonicObsidian.getAttackDamage()), CreativeTabs.MISC);
        // Null-check to ensure that the weapon is enabled.
        if(majestySword != null)
            reg.register(majestySword);
    }
}
