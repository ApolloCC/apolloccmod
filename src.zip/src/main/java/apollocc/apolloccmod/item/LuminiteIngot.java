package apollocc.apolloccmod.item;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class LuminiteIngot extends Item {

}
