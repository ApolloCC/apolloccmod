package apollocc.apolloccmod.item;


import com.sun.org.apache.bcel.internal.classfile.Attribute;

import apollocc.apolloccmod.init.ModItems;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ItemLuminiteArmor extends ItemArmor {
	
	public ItemLuminiteArmor(ArmorMaterial material, EntityEquipmentSlot equipmentSlot) {
		super(material, 0, equipmentSlot);
	}
	
	
	@Override

	public void onArmorTick(World world, EntityPlayer player, ItemStack armor) {
	if (player.getItemStackFromSlot(armorType.CHEST) != null && player.getItemStackFromSlot(armorType.CHEST).getItem().equals(ModItems.LUMINITE_CHESTPLATE)) {
		player.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 20, 0));
			
                                                                                                
		

	}

	if (player.getItemStackFromSlot(armorType.LEGS) != null && player.getItemStackFromSlot(armorType.LEGS).getItem().equals(ModItems.LUMINITE_LEGGINGS)) {

		player.addPotionEffect(new PotionEffect(MobEffects.HEALTH_BOOST, 20, 4));
		
	}

	}
	
}