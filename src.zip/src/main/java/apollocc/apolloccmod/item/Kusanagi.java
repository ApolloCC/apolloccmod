package apollocc.apolloccmod.item;

import com.oblivioussp.spartanweaponry.api.DamageHelper;
import com.oblivioussp.spartanweaponry.api.DamageHelper.WeaponType;
import com.oblivioussp.spartanweaponry.api.SpartanWeaponryAPI;
import com.oblivioussp.spartanweaponry.api.ToolMaterialEx;
import com.oblivioussp.spartanweaponry.api.weaponproperty.WeaponProperty;
import com.oblivioussp.spartanweaponry.api.weaponproperty.WeaponPropertyDamageAbsorb;
import apollocc.apolloccmod.weaponproperty.WeaponPropertySwift;
import apollocc.apolloccmod.weaponproperty.WeaponProperties;

import apollocc.apolloccmod.ApolloCCMod;
import apollocc.apolloccmod.RegistrationHandler;
import apollocc.apolloccmod.util.Reference;
import apollocc.apolloccmod.util.RegistryUtil;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.registries.IForgeRegistry;
@EventBusSubscriber
public class Kusanagi
{
    public static ToolMaterialEx materialKusanagi = new ToolMaterialEx("kusanagi", "ingotKusanagi", Reference.ModID, 0x0F6363, 0x107272, 4, 204800, 17.5f, 25.0f, 30);

    public static Item Kusanagi = null;
    
    public static Item setItemName(final Item item, final String name) {
    	item.setRegistryName(ApolloCCMod.MODID, name).setTranslationKey(ApolloCCMod.MODID + "." + name);
    	return item;
    }
	
    @SubscribeEvent
    public static void onItemRegisterEvent(RegistryEvent.Register<Item> ev)
    {
        IForgeRegistry<Item> reg = ev.getRegistry();

        Kusanagi = SpartanWeaponryAPI.createKatana(materialKusanagi, Reference.ModID, DamageHelper.getDamage(WeaponType.KATANA, materialKusanagi.getAttackDamage()), CreativeTabs.MISC, WeaponProperties.ARMOUR_PIERCING_50, WeaponProperties.REACH_2, WeaponProperties.SWIFT_1, WeaponProperties.SHIELD_BREACH, WeaponProperties.QUICK_STRIKE);
        // Null-check to ensure that the weapon is enabled.
        if(Kusanagi != null)
            reg.register(Kusanagi);
    }
}
